/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment1;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author DEll
 */
@WebServlet(name = "cominsert", urlPatterns = {"/cominsert"})
public class cominsert extends HttpServlet {

    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
          PrintWriter out = response.getWriter();
       
                String regno = request.getParameter("regno");
                String comname = request.getParameter("comname");
                String ceo = request.getParameter("ceo");
                String comcountry = request.getParameter("comcountry");
                String comcity = request.getParameter("comcity");
                String comnumber = request.getParameter("comnumber");
                String comemail = request.getParameter("comemail");
                String compassword = request.getParameter("compassword");
                String comcpassword = request.getParameter("comcpassword");
                
                try {
                    Class.forName("com.mysql.jdbc.Driver");
                    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/connect","root","");
                    Statement st = con.createStatement();
                    int i = st.executeUpdate("insert into company(regno,comname,ceo,comcountry,comcity,comnumber,comemail,compassword,comcpassword) values('"+regno+"','"+comname+"','"+ceo+"','"+comcountry+"','"+comcity+"','"+comnumber+"','"+comemail+"','"+compassword+"','"+comcpassword+"')");
                    if(i>0){
                        response.setContentType("text/html");  
                        out.println("<script type=\"text/javascript\">");  
                        out.println("alert('SUCCESSFULLY ENTERED YOUR DETAILS');");  
                         out.println("location='industry.jsp';");
                        out.println("</script>");
                    }
                    else{
                        out.println("wrong");
                    }
        } catch (Exception e) {
            out.println(e);
        }
    }
    

   

}
